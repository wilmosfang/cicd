var http = require('http');

var handleRequest = function(request, response) {
  console.log('Received request for URL: ' + request.url);
  response.writeHead(200);
  response.write("[");
  response.write(process.env.ENV_TAG);
  response.write("] ");
  response.write(process.env.HOSTNAME);
  response.end(" say: Hello World!  |v2| \n");
};
var www = http.createServer(handleRequest);
www.listen(8080);
